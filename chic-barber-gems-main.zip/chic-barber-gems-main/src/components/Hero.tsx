import { Button } from "@/components/ui/button";
import { Calendar } from "lucide-react";
import logo from "@/assets/logo.png";

export const Hero = () => {
  return (
    <section className="relative min-h-[700px] flex items-center justify-center overflow-hidden bg-gradient-to-b from-black via-black to-background">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-gold/5 via-transparent to-transparent"></div>
      
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <div className="relative mb-12">
            <div className="absolute inset-0 bg-gradient-to-br from-gold to-gold-dark rounded-full blur-3xl opacity-20 animate-pulse"></div>
            <img 
              src={logo} 
              alt="ALME Barbershop" 
              className="relative w-full max-w-md mx-auto drop-shadow-[0_0_50px_rgba(216,180,115,0.3)]"
            />
          </div>
          
          <h1 className="font-bebas text-6xl md:text-8xl font-normal text-cream mb-4 tracking-wider text-shadow-gold animate-fade-in">
            ALME BARBERSHOP
          </h1>
          
          <p className="text-xl md:text-2xl text-cream/80 mb-12 font-light tracking-wide animate-fade-in [animation-delay:200ms] text-shadow-soft">
            Stříhání, úprava a barvení vousů | Komplet servis
          </p>
          
          <Button 
            size="lg"
            className="bg-gradient-to-r from-gold to-gold-dark hover:shadow-[0_0_30px_hsl(var(--gold)/0.5)] text-black font-semibold text-lg px-8 py-6 transition-all duration-300"
            onClick={() => window.open('https://alme.reservanto.cz/', '_blank')}
          >
            <Calendar className="mr-2 h-5 w-5" />
            Rezervovat termín
          </Button>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent"></div>
    </section>
  );
};
