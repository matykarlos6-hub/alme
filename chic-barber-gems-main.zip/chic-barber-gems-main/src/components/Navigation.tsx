import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import logo from "@/assets/logo.png";

export const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  const navItems = [
    { label: "O nás", id: "o-nas" },
    { label: "Služby", id: "sluzby" },
    { label: "Dárkový poukaz", id: "darkovy-poukaz" },
    { label: "Recenze", id: "recenze" },
    { label: "Kontakt", id: "kontakt" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-sm border-b border-gold/20">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <img src={logo} alt="ALME Barbershop" className="h-14 w-14 object-contain" />
            <span className="text-xl font-bold text-cream">ALME BARBERSHOP</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-cream hover:text-gold transition-colors duration-300 font-medium"
              >
                {item.label}
              </button>
            ))}
            <Button 
              onClick={() => window.open('https://alme.reservanto.cz/', '_blank')}
              className="bg-gradient-to-r from-gold to-gold-dark hover:shadow-[0_0_20px_hsl(var(--gold)/0.5)] text-black font-semibold transition-all duration-300"
            >
              Rezervovat
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-cream hover:text-gold transition-colors"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden pb-6">
            <div className="flex flex-col gap-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="text-cream hover:text-gold transition-colors duration-300 font-medium text-left"
                >
                  {item.label}
                </button>
              ))}
              <Button 
                onClick={() => {
                  window.open('https://alme.reservanto.cz/', '_blank');
                  setIsOpen(false);
                }}
                className="bg-gradient-to-r from-gold to-gold-dark hover:shadow-[0_0_20px_hsl(var(--gold)/0.5)] text-black font-semibold transition-all duration-300"
              >
                Rezervovat
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};
