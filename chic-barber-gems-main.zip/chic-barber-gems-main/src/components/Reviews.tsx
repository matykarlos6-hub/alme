import { Star, Quote } from "lucide-react";

const reviews = [
  {
    name: "Tomáš Krejčík",
    text: "Jestli se bojíte o střih, schválně jděte sem! Já Nikdy nepůjdu jinam! Takového hledání a konečně člověk co ví co dělá a dělá to rád. Střih uplně top, cena 500 i s dýškem. A barber takovej, že se chcete brzo vrátit ;) Díky moc!",
    rating: 5,
  },
  {
    name: "Oldřich Šedivý",
    text: "Vyzkoušel jsem plno Barberů, ale tady se nikdo nevyrovná. Alex odvedl suprovou práci! Na příští návštěvu se těším. Nejlepší služba fakt profík!",
    rating: 5,
  },
];

export const Reviews = () => {
  return (
    <section className="py-20" id="recenze">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-4xl mx-auto mb-12">
          <h2 className="text-4xl md:text-5xl font-bebas font-bold mb-4 text-foreground text-shadow-soft animate-fade-in">
            Co říkají naši zákazníci
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-gold to-gold-dark mx-auto mb-6"></div>
          <p className="text-muted-foreground text-lg">
            Přečtěte si zkušenosti našich spokojených klientů
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-6">
          {reviews.map((review, index) => (
            <div
              key={index}
              className="bg-white/90 backdrop-blur-md border-2 border-gold/60 rounded-xl p-8 shadow-[0_0_20px_hsl(var(--gold)/0.4)] hover:shadow-[0_0_40px_hsl(var(--gold)/0.6)] hover:border-gold transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className="flex items-start gap-4">
                <Quote className="h-6 w-6 text-gold flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <div className="flex gap-1 mb-3">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-gold text-gold" />
                    ))}
                  </div>
                  <p className="text-black leading-relaxed mb-4 text-lg">
                    {review.text}
                  </p>
                  <p className="text-gold font-semibold">
                    — {review.name}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
