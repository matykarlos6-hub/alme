import logo from "@/assets/logo.png";

export const Footer = () => {
  return (
    <footer className="bg-black text-cream py-12 border-t border-gold/20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center">
          <img src={logo} alt="ALME Barbershop" className="h-24 w-24 object-contain mb-4" />
          <h3 className="text-2xl font-bold mb-2">ALME BARBERSHOP</h3>
          <p className="text-cream/70 mb-2">Masarykova 1091/130, Ústí nad Labem</p>
          <p className="text-cream/70 mb-4">Stříhání, úprava a barvení vousů | Komplet servis</p>
          
          <div className="mt-8 pt-8 border-t border-gold/20 w-full">
            <p className="text-cream/60 text-sm">
              © {new Date().getFullYear()} ALME Barbershop. Všechna práva vyhrazena.
            </p>
            <p className="text-cream/60 text-sm mt-2">
              Online rezervační systém na{" "}
              <a 
                href="https://alme.reservanto.cz/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gold hover:underline"
              >
                alme.reservanto.cz
              </a>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};
