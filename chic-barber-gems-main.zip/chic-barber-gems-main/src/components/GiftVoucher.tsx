import { Gift } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export const GiftVoucher = () => {
  return (
    <section className="py-20 bg-background" id="darkovy-poukaz">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <Card className="p-12 bg-gradient-to-br from-background to-accent/5 border-gold/20 text-center">
            <div className="inline-block p-4 bg-gold/10 rounded-full mb-6">
              <Gift className="h-16 w-16 text-gold" />
            </div>
            
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Daruj dárkový poukaz
            </h2>
            
            <p className="text-muted-foreground text-lg mb-8">
              Zakoupit můžete přímo u nás v barbershopu
            </p>
            
            <Button
              size="lg"
              className="bg-gradient-to-r from-gold to-gold-dark hover:shadow-[0_0_30px_hsl(var(--gold)/0.5)] text-black font-semibold text-lg px-8 py-6 transition-all duration-300"
              onClick={() => window.open('https://alme.reservanto.cz/', '_blank')}
            >
              <Gift className="mr-2 h-5 w-5" />
              Rezervovat termín
            </Button>
          </Card>
        </div>
      </div>
    </section>
  );
};
