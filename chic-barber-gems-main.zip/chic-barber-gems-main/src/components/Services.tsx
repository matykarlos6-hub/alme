import { Scissors, Sparkles, Crown, Baby, Users, Paintbrush, Wind } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const services = [
  {
    icon: Scissors,
    title: "Střih",
    duration: "až 30min",
    description: "Střih, mytí, úprava kontur a obočí, aplikace kolínské, styling",
    price: "390 Kč"
  },
  {
    icon: Sparkles,
    title: "Komplet servis",
    duration: "až 60min",
    description: "Střih, mytí, úprava kontur a obočí, úprava vousů, napaření horkým ručníkem, hydratační sérum, aplikace kolínské",
    price: "590 Kč",
    recommended: true
  },
  {
    icon: Crown,
    title: "AlMe VIP",
    duration: "až 90min",
    description: "Střih, mytí, úprava kontur a obočí, úprava vousů, napaření horkým ručníkem, čistící maska, hydratační sérum, aplikace kolínské, barvení vousů, masáž hlavy, zaholení uší, vosk, nápoj zdarma",
    price: "910 Kč"
  },
  {
    icon: Baby,
    title: "Dětský střih do 11ti let",
    duration: "až 30min",
    description: "Střih, úprava kontur, styling",
    price: "280 Kč"
  },
  {
    icon: Users,
    title: "Úprava vousů",
    duration: "30min",
    description: "Napaření horkým ručníkem, úprava vousů, úprava kontur, úprava obočí, hydratační sérum, aplikace kolínské",
    price: "320 Kč"
  },
  {
    icon: Paintbrush,
    title: "Barvení vousů",
    duration: "30min",
    description: "Aplikace barvy a hydratačního séra",
    price: "160 Kč"
  },
  {
    icon: Wind,
    title: "Depilace voskem",
    duration: "10min",
    description: "Odstranění chloupků z uší a nosu",
    price: "70 Kč"
  }
];

export const Services = () => {
  return (
    <section className="py-20 bg-background" id="sluzby">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-bebas text-5xl md:text-6xl font-normal text-foreground mb-4 tracking-wider text-shadow-soft">
            Naše služby
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-gold to-gold-dark mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card 
                key={index}
                className="p-6 hover:shadow-[0_8px_30px_hsl(var(--gold)/0.2)] transition-all duration-300 border-border bg-card group animate-fade-in relative"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {service.recommended && (
                  <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-gold to-gold-dark text-black font-semibold">
                    Doporučujeme
                  </Badge>
                )}
                
                <div className="mb-4 inline-block p-3 bg-gradient-to-br from-gold/20 to-gold-dark/20 rounded-lg group-hover:scale-110 transition-transform duration-300">
                  <Icon className="h-7 w-7 text-gold" />
                </div>
                
                <h3 className="text-xl font-bold text-foreground mb-2 text-shadow-soft">
                  {service.title}
                </h3>
                
                <p className="text-sm text-gold/80 mb-3 font-medium">
                  {service.duration}
                </p>
                
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                  {service.description}
                </p>
                
                <div className="text-2xl font-bold text-gold">
                  {service.price}
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};
