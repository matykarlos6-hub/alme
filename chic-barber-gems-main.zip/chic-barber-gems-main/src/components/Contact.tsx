import { Button } from "@/components/ui/button";
import { MapPin, Phone, Clock, Calendar, Mail } from "lucide-react";
import { Card } from "@/components/ui/card";

export const Contact = () => {
  return (
    <section className="py-20 bg-background" id="kontakt">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-shadow-soft">
            Kde nás najdete?
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-gold to-gold-dark mx-auto"></div>
        </div>
        
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="p-8 border-border bg-card animate-fade-in" style={{ animationDelay: '0ms' }}>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-gold/10 rounded-lg">
                  <MapPin className="h-6 w-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-xl mb-2 text-foreground">Adresa</h3>
                  <p className="text-muted-foreground">
                    Masarykova 1091/130<br />
                    Ústí nad Labem
                  </p>
                </div>
              </div>
            </Card>
            
            <Card className="p-8 border-border bg-card animate-fade-in" style={{ animationDelay: '100ms' }}>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-gold/10 rounded-lg">
                  <Phone className="h-6 w-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-xl mb-2 text-foreground">Telefon</h3>
                  <a href="tel:+420736222164" className="text-muted-foreground hover:text-gold transition-colors">
                    +420 736 222 164
                  </a>
                </div>
              </div>
            </Card>
            
            <Card className="p-8 border-border bg-card animate-fade-in" style={{ animationDelay: '200ms' }}>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-gold/10 rounded-lg">
                  <Mail className="h-6 w-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-xl mb-2 text-foreground">Email</h3>
                  <a href="mailto:almebarbershop@gmail.com" className="text-muted-foreground hover:text-gold transition-colors">
                    almebarbershop@gmail.com
                  </a>
                </div>
              </div>
            </Card>
            
            <Card className="p-8 border-border bg-card animate-fade-in" style={{ animationDelay: '300ms' }}>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-gold/10 rounded-lg">
                  <Clock className="h-6 w-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-xl mb-2 text-foreground">Otevírací doba</h3>
                  <p className="text-muted-foreground">
                    Út-Pá: 10:00 - 19:00<br />
                    So: 10:00 - 17:00<br />
                    Ne: na objednání
                  </p>
                </div>
              </div>
            </Card>
          </div>
          
          <Card className="p-8 border-gold/30 bg-gradient-to-br from-card to-gold/5">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="p-3 bg-gold/10 rounded-lg">
                <Calendar className="h-6 w-6 text-gold" />
              </div>
              <h3 className="font-bold text-xl text-foreground">Online rezervace</h3>
              <p className="text-muted-foreground mb-4">
                Využijte náš online rezervační systém pro rychlé a pohodlné objednání
              </p>
              <Button 
                variant="outline"
                size="lg"
                className="border-gold text-gold hover:bg-gold hover:text-black transition-all duration-300"
                onClick={() => window.open('https://alme.reservanto.cz/', '_blank')}
              >
                Rezervovat online
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};
