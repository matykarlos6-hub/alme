import logo from "@/assets/logo.png";

export const About = () => {
  return (
    <section className="py-20 bg-card" id="o-nas">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-shadow-soft">
                O nás
              </h2>
              <div className="w-24 h-1 bg-gradient-to-r from-gold to-gold-dark mb-6"></div>
              
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                ALME Barbershop je místem, kde se tradice setkává s moderním stylem. Zkušený barber kombinuje klasické techniky s nejnovějšími trendy, aby vám poskytl nejlepší možnou péči.
              </p>
              
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Nabízíme kompletní servis péče o vlasy a vousy v luxusním a příjemném prostředí. Používáme pouze prémiové produkty a nástroje pro dosažení dokonalých výsledků.
              </p>
              
              <p className="text-lg text-muted-foreground leading-relaxed">
                Najdete nás v Ústí nad Labem na Masarykově ulici, kde na vás čeká profesionální barber připravený splnit všechna vaše očekávání.
              </p>
            </div>
            
            <div className="order-1 md:order-2 flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-gold to-gold-dark rounded-full blur-3xl opacity-20 animate-pulse"></div>
                <img 
                  src={logo} 
                  alt="ALME Barbershop Logo" 
                  className="relative w-96 h-96 object-contain drop-shadow-[0_0_50px_rgba(216,180,115,0.3)]"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
